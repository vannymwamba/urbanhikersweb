// API service for corporate bookings
import { mockCorporateBookings } from './mockData';

// Simulate API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Submit corporate booking request
const submitCorporateBooking = async (bookingData) => {
  // Simulate API call
  await delay(1500);
  
  // Create new booking
  const newBooking = {
    id: mockCorporateBookings.length + 1,
    ...bookingData,
    status: 'pending',
    submittedAt: new Date().toISOString()
  };
  
  // In a real app, this would be saved to a database
  mockCorporateBookings.push(newBooking);
  
  return { 
    success: true, 
    booking: newBooking,
    message: 'Your corporate booking request has been submitted successfully. Our team will contact you within 24 hours to confirm details.'
  };
};

// Get corporate booking by ID
const getCorporateBookingById = async (id) => {
  // Simulate API call
  await delay(500);
  
  const booking = mockCorporateBookings.find(b => b.id === parseInt(id));
  
  if (booking) {
    return booking;
  } else {
    throw new Error('Booking not found');
  }
};

// Get corporate bookings by company
const getCorporateBookingsByCompany = async (companyName) => {
  // Simulate API call
  await delay(800);
  
  const bookings = mockCorporateBookings.filter(b => 
    b.companyName.toLowerCase().includes(companyName.toLowerCase())
  );
  
  return bookings;
};

// Update corporate booking
const updateCorporateBooking = async (id, updateData) => {
  // Simulate API call
  await delay(1000);
  
  const bookingIndex = mockCorporateBookings.findIndex(b => b.id === parseInt(id));
  
  if (bookingIndex === -1) {
    throw new Error('Booking not found');
  }
  
  // Update booking
  mockCorporateBookings[bookingIndex] = {
    ...mockCorporateBookings[bookingIndex],
    ...updateData,
    updatedAt: new Date().toISOString()
  };
  
  return { 
    success: true, 
    booking: mockCorporateBookings[bookingIndex]
  };
};

// Cancel corporate booking
const cancelCorporateBooking = async (id) => {
  // Simulate API call
  await delay(1000);
  
  const bookingIndex = mockCorporateBookings.findIndex(b => b.id === parseInt(id));
  
  if (bookingIndex === -1) {
    throw new Error('Booking not found');
  }
  
  // Check if booking is already cancelled
  if (mockCorporateBookings[bookingIndex].status === 'cancelled') {
    throw new Error('Booking is already cancelled');
  }
  
  // Update booking status
  mockCorporateBookings[bookingIndex].status = 'cancelled';
  mockCorporateBookings[bookingIndex].cancelledAt = new Date().toISOString();
  
  return { 
    success: true,
    message: 'Your corporate booking has been cancelled successfully.'
  };
};

export const corporateService = {
  submitCorporateBooking,
  getCorporateBookingById,
  getCorporateBookingsByCompany,
  updateCorporateBooking,
  cancelCorporateBooking
};
