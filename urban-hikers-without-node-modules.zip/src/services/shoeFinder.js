// API service for shoe finder and recommendations
import { mockShoeRecommendations } from './mockData';

// Simulate API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Analyze biometric data and return foot profile
const analyzeBiometricData = async (biometricData) => {
  // Simulate API call and complex analysis
  await delay(2000);
  
  // In a real app, this would be a complex algorithm analyzing the biometric data
  // For demo purposes, we're returning a simplified analysis
  const footProfile = {
    archType: determinArchType(biometricData),
    footWidth: determineFootWidth(biometricData),
    pronation: determinePronation(biometricData),
    gaitType: determineGaitType(biometricData)
  };
  
  return footProfile;
};

// Helper functions for biometric analysis
const determinArchType = (data) => {
  // Using arch height from biometric data
  const archHeight = data.archHeight || data.measurements?.arch_height || 0;
  
  if (archHeight < 1.5) return 'Low';
  if (archHeight < 2.5) return 'Medium';
  return 'High';
};

const determineFootWidth = (data) => {
  // Using foot width from biometric data
  const footWidth = data.footWidth || data.measurements?.foot_width || 0;
  
  if (footWidth < 9) return 'Narrow';
  if (footWidth < 10.5) return 'Regular';
  return 'Wide';
};

const determinePronation = (data) => {
  // Using various measurements to determine pronation
  const pronationValue = data.pronationValue || data.measurements?.pronation_value || 0;
  
  if (pronationValue < 4) return 'Supination';
  if (pronationValue < 7) return 'Neutral';
  return 'Overpronation';
};

const determineGaitType = (data) => {
  // Using various measurements to determine gait type
  return 'Balanced'; // Default for demo
};

// Get shoe recommendations based on foot profile and preferences
const getShoeRecommendations = async (footProfile, preferences) => {
  // Simulate API call
  await delay(1500);
  
  // In a real app, this would match the foot profile and preferences with a database of shoes
  // For demo purposes, we're returning mock recommendations with match scores
  
  // Sort recommendations by match score
  const sortedRecommendations = [...mockShoeRecommendations].sort((a, b) => {
    // Adjust match scores based on foot profile and preferences
    let aScore = a.matchScore;
    let bScore = b.matchScore;
    
    // Adjust scores based on activity level
    if (preferences?.activityLevel === 'athletic' && a.category.includes('Trail')) {
      aScore += 3;
    }
    if (preferences?.activityLevel === 'light' && a.category.includes('Comfort')) {
      aScore += 3;
    }
    
    // Adjust scores based on terrain
    if (preferences?.terrainType === 'trail' && a.category.includes('Hiking')) {
      aScore += 3;
    }
    if (preferences?.terrainType === 'urban' && a.category.includes('Urban')) {
      aScore += 3;
    }
    
    return bScore - aScore; // Sort descending
  });
  
  return sortedRecommendations;
};

// Get detailed information about a specific shoe
const getShoeDetails = async (shoeId) => {
  // Simulate API call
  await delay(800);
  
  const shoe = mockShoeRecommendations.find(s => s.id === parseInt(shoeId));
  
  if (shoe) {
    // Add more detailed information
    return {
      ...shoe,
      description: 'This premium urban hiking shoe is designed for maximum comfort and support during extended city walks. Features include responsive cushioning, breathable materials, and durable construction.',
      features: [
        'Breathable mesh upper with synthetic overlays',
        'Responsive cushioning for all-day comfort',
        'Durable rubber outsole with urban terrain pattern',
        'Removable insole for custom orthotics',
        'Reflective elements for visibility'
      ],
      sizes: ['7', '7.5', '8', '8.5', '9', '9.5', '10', '10.5', '11', '11.5', '12'],
      colors: ['Black/Gray', 'Blue/White', 'Green/Black'],
      materials: ['Synthetic mesh', 'Rubber', 'EVA foam'],
      careInstructions: 'Clean with mild soap and water. Air dry away from direct heat.'
    };
  } else {
    throw new Error('Shoe not found');
  }
};

export const shoeFinderService = {
  analyzeBiometricData,
  getShoeRecommendations,
  getShoeDetails
};
