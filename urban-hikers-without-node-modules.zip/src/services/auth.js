// API service for authentication
import { mockUsers } from './mockData';

// Simulate API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Local storage keys
const TOKEN_KEY = 'urban_hikers_token';
const USER_KEY = 'urban_hikers_user';

// Check if user is logged in
const isAuthenticated = () => {
  return localStorage.getItem(TOKEN_KEY) !== null;
};

// Get current user
const getCurrentUser = () => {
  const userJson = localStorage.getItem(USER_KEY);
  return userJson ? JSON.parse(userJson) : null;
};

// Login user
const login = async (email, password) => {
  // Simulate API call
  await delay(1000);
  
  const user = mockUsers.find(u => u.email === email && u.password === password);
  
  if (user) {
    // Create a mock token
    const token = `mock-jwt-token-${Math.random().toString(36).substring(2)}`;
    
    // Store in localStorage
    localStorage.setItem(TOKEN_KEY, token);
    
    // Store user without password
    const { password, ...userWithoutPassword } = user;
    localStorage.setItem(USER_KEY, JSON.stringify(userWithoutPassword));
    
    return { success: true, user: userWithoutPassword };
  } else {
    throw new Error('Invalid email or password');
  }
};

// Register user
const register = async (userData) => {
  // Simulate API call
  await delay(1500);
  
  // Check if email already exists
  const existingUser = mockUsers.find(u => u.email === userData.email);
  if (existingUser) {
    throw new Error('Email already in use');
  }
  
  // Create new user
  const newUser = {
    id: mockUsers.length + 1,
    ...userData,
    createdAt: new Date().toISOString()
  };
  
  // In a real app, this would be saved to a database
  mockUsers.push(newUser);
  
  // Create a mock token
  const token = `mock-jwt-token-${Math.random().toString(36).substring(2)}`;
  
  // Store in localStorage
  localStorage.setItem(TOKEN_KEY, token);
  
  // Store user without password
  const { password, ...userWithoutPassword } = newUser;
  localStorage.setItem(USER_KEY, JSON.stringify(userWithoutPassword));
  
  return { success: true, user: userWithoutPassword };
};

// Logout user
const logout = () => {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  return { success: true };
};

// Update user profile
const updateProfile = async (userData) => {
  // Simulate API call
  await delay(1000);
  
  const currentUser = getCurrentUser();
  if (!currentUser) {
    throw new Error('Not authenticated');
  }
  
  // Update user in mock data
  const userIndex = mockUsers.findIndex(u => u.id === currentUser.id);
  if (userIndex !== -1) {
    mockUsers[userIndex] = { ...mockUsers[userIndex], ...userData };
    
    // Update localStorage
    const { password, ...userWithoutPassword } = mockUsers[userIndex];
    localStorage.setItem(USER_KEY, JSON.stringify(userWithoutPassword));
    
    return { success: true, user: userWithoutPassword };
  } else {
    throw new Error('User not found');
  }
};

// Change password
const changePassword = async (currentPassword, newPassword) => {
  // Simulate API call
  await delay(1000);
  
  const currentUser = getCurrentUser();
  if (!currentUser) {
    throw new Error('Not authenticated');
  }
  
  // Find user in mock data
  const userIndex = mockUsers.findIndex(u => u.id === currentUser.id);
  if (userIndex !== -1) {
    // Verify current password
    if (mockUsers[userIndex].password !== currentPassword) {
      throw new Error('Current password is incorrect');
    }
    
    // Update password
    mockUsers[userIndex].password = newPassword;
    
    return { success: true };
  } else {
    throw new Error('User not found');
  }
};

export const authService = {
  isAuthenticated,
  getCurrentUser,
  login,
  register,
  logout,
  updateProfile,
  changePassword
};
