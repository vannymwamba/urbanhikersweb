// API service for events
import { mockEvents, mockBookings } from './mockData';

// Simulate API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Get all events
const getAllEvents = async () => {
  // Simulate API call
  await delay(800);
  
  return mockEvents;
};

// Get event by ID
const getEventById = async (id) => {
  // Simulate API call
  await delay(500);
  
  const event = mockEvents.find(e => e.id === parseInt(id));
  
  if (event) {
    return event;
  } else {
    throw new Error('Event not found');
  }
};

// Get events by category
const getEventsByCategory = async (category) => {
  // Simulate API call
  await delay(800);
  
  const events = mockEvents.filter(e => e.category === category);
  
  return events;
};

// Book an event
const bookEvent = async (bookingData) => {
  // Simulate API call
  await delay(1200);
  
  // Check if event exists
  const event = mockEvents.find(e => e.id === bookingData.eventId);
  if (!event) {
    throw new Error('Event not found');
  }
  
  // Check if spots are available
  if (event.spotsLeft < bookingData.participants) {
    throw new Error('Not enough spots available');
  }
  
  // Create new booking
  const newBooking = {
    id: mockBookings.length + 1,
    ...bookingData,
    status: 'confirmed',
    bookedAt: new Date().toISOString()
  };
  
  // In a real app, this would be saved to a database
  mockBookings.push(newBooking);
  
  // Update spots left
  event.spotsLeft -= bookingData.participants;
  
  return { success: true, booking: newBooking };
};

// Get user bookings
const getUserBookings = async (userId) => {
  // Simulate API call
  await delay(800);
  
  const bookings = mockBookings.filter(b => b.userId === userId);
  
  // Enrich with event data
  const enrichedBookings = bookings.map(booking => {
    const event = mockEvents.find(e => e.id === booking.eventId);
    return {
      ...booking,
      eventTitle: event ? event.title : 'Unknown Event',
      eventLocation: event ? event.location : 'Unknown Location'
    };
  });
  
  return enrichedBookings;
};

// Cancel booking
const cancelBooking = async (bookingId, userId) => {
  // Simulate API call
  await delay(1000);
  
  const bookingIndex = mockBookings.findIndex(b => b.id === bookingId && b.userId === userId);
  
  if (bookingIndex === -1) {
    throw new Error('Booking not found');
  }
  
  const booking = mockBookings[bookingIndex];
  
  // Check if booking is already cancelled
  if (booking.status === 'cancelled') {
    throw new Error('Booking is already cancelled');
  }
  
  // Update booking status
  mockBookings[bookingIndex].status = 'cancelled';
  
  // Return spots to event
  const event = mockEvents.find(e => e.id === booking.eventId);
  if (event) {
    event.spotsLeft += booking.participants;
  }
  
  return { success: true };
};

export const eventsService = {
  getAllEvents,
  getEventById,
  getEventsByCategory,
  bookEvent,
  getUserBookings,
  cancelBooking
};
