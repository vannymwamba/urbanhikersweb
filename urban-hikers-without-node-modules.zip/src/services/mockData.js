// Mock data for events
export const mockEvents = [
  {
    id: 1,
    title: 'Historical Downtown Tour',
    date: 'April 15, 2025',
    time: '10:00 AM - 12:30 PM',
    location: 'City Center',
    meetingPoint: 'Central Square Fountain',
    image: '/images/placeholder/downtown.jpg',
    price: 25,
    spotsLeft: 8,
    category: 'historical',
    description: 'Join us for a fascinating journey through the historical heart of downtown. This guided walk will take you through centuries of urban development, architectural marvels, and the stories behind the city\'s most iconic landmarks. Our expert guide will share insights about the cultural and historical significance of each location.',
    highlights: [
      'Visit 5 historical landmarks',
      'Learn about architectural styles spanning 3 centuries',
      'Discover hidden courtyards and secret passages',
      'Hear fascinating stories about the city\'s founders',
      'Small group size for a personalized experience'
    ],
    includes: [
      'Professional guide',
      'Bottled water',
      'Historical map souvenir',
      'Access to exclusive locations'
    ],
    guide: {
      name: 'Professor Alex Thompson',
      bio: 'Alex is a history professor with over 15 years of experience leading urban tours. His passion for local history and engaging storytelling style make each tour educational and entertaining.',
      image: '/images/placeholder/guide.jpg'
    },
    duration: '2.5 hours',
    distance: '2.5 miles',
    difficulty: 'Easy',
    maxParticipants: 12
  },
  {
    id: 2,
    title: 'Street Art Discovery Walk',
    date: 'April 18, 2025',
    time: '2:00 PM - 4:00 PM',
    location: 'Arts District',
    meetingPoint: 'Mural Plaza Entrance',
    image: '/images/placeholder/street-art.jpg',
    price: 20,
    spotsLeft: 12,
    category: 'cultural',
    description: 'Explore the vibrant street art scene of our city\'s Arts District. This walk takes you through colorful alleys and hidden corners where local and international artists have transformed urban spaces into open-air galleries. Learn about different styles, techniques, and the stories behind the most iconic murals.',
    highlights: [
      'Visit over 20 significant murals and installations',
      'Learn about street art techniques and styles',
      'Meet a local artist (when available)',
      'Photo opportunities at Instagram-worthy spots',
      'Discover the neighborhood\'s transformation through art'
    ],
    includes: [
      'Expert art guide',
      'Street art map',
      'Bottled water',
      'Small group size (max 15 people)'
    ],
    guide: {
      name: 'Maya Rodriguez',
      bio: 'Maya is an artist and art historian specializing in urban art movements. She has documented the city\'s street art evolution for over a decade and knows many of the artists personally.',
      image: '/images/placeholder/guide2.jpg'
    },
    duration: '2 hours',
    distance: '1.8 miles',
    difficulty: 'Easy',
    maxParticipants: 15
  },
  {
    id: 3,
    title: 'Urban Nature Hike',
    date: 'April 22, 2025',
    time: '9:00 AM - 11:30 AM',
    location: 'Riverside Park',
    meetingPoint: 'North Entrance Pavilion',
    image: '/images/placeholder/urban-nature.jpg',
    price: 22,
    spotsLeft: 5,
    category: 'nature',
    description: 'Discover the surprising biodiversity that thrives within our urban environment. This guided nature walk explores parks, green corridors, and urban forests that provide habitat for local wildlife. Learn about urban ecology, conservation efforts, and how nature adapts to city life.',
    highlights: [
      'Identify local plant species and their uses',
      'Spot urban wildlife in their natural habitats',
      'Learn about urban ecology and conservation',
      'Visit community gardens and green initiatives',
      'Peaceful respite from city noise'
    ],
    includes: [
      'Naturalist guide',
      'Binoculars for wildlife spotting',
      'Urban field guide booklet',
      'Refreshments'
    ],
    guide: {
      name: 'Dr. James Wilson',
      bio: 'James is an urban ecologist with a PhD in Environmental Science. He specializes in urban biodiversity and has led conservation projects throughout the city for over 15 years.',
      image: '/images/placeholder/guide3.jpg'
    },
    duration: '2.5 hours',
    distance: '2.2 miles',
    difficulty: 'Moderate',
    maxParticipants: 10
  },
  {
    id: 4,
    title: 'Architectural Wonders Walk',
    date: 'April 25, 2025',
    time: '1:00 PM - 3:30 PM',
    location: 'Downtown',
    meetingPoint: 'City Hall Steps',
    image: '/images/placeholder/architecture.jpg',
    price: 28,
    spotsLeft: 15,
    category: 'architectural',
    description: 'Explore the city\'s most impressive architectural achievements spanning different eras and styles. This walk takes you from historic buildings to modern skyscrapers, examining the evolution of urban design and the stories behind iconic structures that define our skyline.',
    highlights: [
      'Visit 8 architecturally significant buildings',
      'Access to exclusive building interiors (when available)',
      'Learn about different architectural styles and periods',
      'Understand urban planning principles',
      'Spectacular city views from select locations'
    ],
    includes: [
      'Architecture expert guide',
      'Building access fees',
      'Architecture guidebook',
      'Bottled water'
    ],
    guide: {
      name: 'Sophia Chen',
      bio: 'Sophia is an architect with a specialization in urban design history. She has published several books on the city\'s architectural evolution and teaches at the local university.',
      image: '/images/placeholder/guide4.jpg'
    },
    duration: '2.5 hours',
    distance: '1.5 miles',
    difficulty: 'Easy',
    maxParticipants: 20
  },
  {
    id: 5,
    title: 'Culinary Tour & Tastings',
    date: 'April 29, 2025',
    time: '11:00 AM - 2:00 PM',
    location: 'Food District',
    meetingPoint: 'Central Market Entrance',
    image: '/images/placeholder/culinary.jpg',
    price: 35,
    spotsLeft: 6,
    category: 'culinary',
    description: 'Savor the diverse flavors of our city on this walking food tour. Visit local markets, family-owned eateries, and hidden culinary gems while learning about the cultural influences that have shaped our local food scene. Enjoy multiple tastings that tell the story of our city\'s culinary heritage.',
    highlights: [
      '6+ food tastings at different locations',
      'Meet local food artisans and chefs',
      'Learn about culinary history and influences',
      'Discover hidden food gems off the tourist path',
      'Small group for an intimate experience'
    ],
    includes: [
      'Food guide',
      'All food tastings',
      'One beverage',
      'Food map with recommendations',
      'Discount vouchers for select restaurants'
    ],
    guide: {
      name: 'Chef Marco Rossi',
      bio: 'Marco is a former restaurant chef turned food historian. His knowledge of local food culture and personal connections with vendors and restaurant owners provides a unique insider perspective.',
      image: '/images/placeholder/guide5.jpg'
    },
    duration: '3 hours',
    distance: '1.5 miles',
    difficulty: 'Easy',
    maxParticipants: 8
  },
  {
    id: 6,
    title: 'Night Photography Walk',
    date: 'May 2, 2025',
    time: '7:30 PM - 10:00 PM',
    location: 'City Lights Area',
    meetingPoint: 'Waterfront Plaza',
    image: '/images/placeholder/night.jpg',
    price: 30,
    spotsLeft: 10,
    category: 'photography',
    description: 'Capture the magic of the city after dark on this photography-focused walking tour. Learn techniques for night photography while visiting the most photogenic illuminated landmarks, light installations, and scenic viewpoints. Suitable for all camera types, including smartphones.',
    highlights: [
      'Visit 7 prime night photography locations',
      'Learn night photography techniques',
      'Capture iconic city landmarks illuminated',
      'Personalized photography tips',
      'Tripod loan available'
    ],
    includes: [
      'Photography instructor guide',
      'Tripod loan (limited quantity, reserve in advance)',
      'Photography technique guide',
      'Hot beverage'
    ],
    guide: {
      name: 'Nathan Park',
      bio: 'Nathan is a professional photographer specializing in urban nightscapes. His work has been featured in several galleries and publications, and he enjoys sharing technical and creative photography knowledge.',
      image: '/images/placeholder/guide6.jpg'
    },
    duration: '2.5 hours',
    distance: '1.8 miles',
    difficulty: 'Easy',
    maxParticipants: 12
  }
];

// Mock data for users
export const mockUsers = [
  {
    id: 1,
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com',
    password: 'password123',
    phone: '(555) 123-4567',
    createdAt: '2024-01-15T10:30:00Z'
  },
  {
    id: 2,
    firstName: 'Jane',
    lastName: 'Smith',
    email: 'jane.smith@example.com',
    password: 'password456',
    phone: '(555) 987-6543',
    createdAt: '2024-02-20T14:45:00Z'
  }
];

// Mock data for bookings
export const mockBookings = [
  {
    id: 1,
    userId: 1,
    eventId: 1,
    date: 'April 15, 2025',
    time: '10:00 AM - 12:30 PM',
    participants: 2,
    totalPrice: 50,
    status: 'confirmed',
    bookedAt: '2025-03-10T09:15:00Z'
  },
  {
    id: 2,
    userId: 1,
    eventId: 3,
    date: 'April 22, 2025',
    time: '9:00 AM - 11:30 AM',
    participants: 1,
    totalPrice: 22,
    status: 'confirmed',
    bookedAt: '2025-03-15T11:30:00Z'
  },
  {
    id: 3,
    userId: 2,
    eventId: 2,
    date: 'April 18, 2025',
    time: '2:00 PM - 4:00 PM',
    participants: 3,
    totalPrice: 60,
    status: 'confirmed',
    bookedAt: '2025-03-12T16:45:00Z'
  }
];

// Mock data for corporate bookings
export const mockCorporateBookings = [
  {
    id: 1,
    companyName: 'Tech Innovations Inc.',
    contactName: 'Sarah Johnson',
    email: 'sarah.johnson@techinnovations.com',
    phone: '(555) 234-5678',
    participants: '11-20',
    walkType: 'teambuilding',
    preferredDate: '2025-05-15',
    alternateDate: '2025-05-22',
    specialRequirements: 'We would like to include some team-building exercises during the walk.',
    status: 'pending',
    submittedAt: '2025-03-20T13:20:00Z'
  },
  {
    id: 2,
    companyName: 'Global Finance Group',
    contactName: 'Michael Chen',
    email: 'mchen@globalfinance.com',
    phone: '(555) 876-5432',
    participants: '21-30',
    walkType: 'historical',
    preferredDate: '2025-06-10',
    alternateDate: '2025-06-17',
    specialRequirements: 'We need the tour to be accessible for all participants, including one person who uses a wheelchair.',
    status: 'confirmed',
    submittedAt: '2025-03-15T10:45:00Z'
  }
];

// Mock data for shoe recommendations
export const mockShoeRecommendations = [
  {
    id: 1,
    name: 'TrailMaster Pro',
    category: 'Urban Hiking Shoe',
    price: 129.99,
    rating: 5.0,
    reviewCount: 128,
    image: '/images/placeholder/shoe1.jpg',
    matchScore: 98,
    matchReasons: [
      'Perfect support for your medium-high arch',
      'Optimal width for your foot shape',
      'Enhanced cushioning for urban terrain',
      'Durable construction for your activity level'
    ]
  },
  {
    id: 2,
    name: 'CityWalker Elite',
    category: 'Urban Comfort Shoe',
    price: 109.99,
    rating: 4.8,
    reviewCount: 96,
    image: '/images/placeholder/shoe2.jpg',
    matchScore: 95,
    matchReasons: [
      'Excellent arch support for your foot type',
      'Breathable materials ideal for long walks',
      'Lightweight design reduces fatigue',
      'Flexible sole matches your walking style'
    ]
  },
  {
    id: 3,
    name: 'UrbanTrek Lite',
    category: 'Lightweight Walking Shoe',
    price: 89.99,
    rating: 4.2,
    reviewCount: 74,
    image: '/images/placeholder/shoe3.jpg',
    matchScore: 92,
    matchReasons: [
      'Lightweight design ideal for your walking style',
      'Good arch support for medium arches',
      'Breathable upper keeps feet cool',
      'Versatile for various urban terrains'
    ]
  }
];
