import React from 'react';

const WalkTypeSelector = ({ selectedType, onSelect }) => {
  const walkTypes = [
    {
      id: 'historical',
      title: 'Historical Tour',
      description: 'Explore the rich history of the city with stories about landmarks, architecture, and cultural significance.'
    },
    {
      id: 'teambuilding',
      title: 'Team Building Focus',
      description: 'Interactive challenges and activities designed to improve communication and collaboration.'
    },
    {
      id: 'wellness',
      title: 'Wellness Walk',
      description: 'Focus on mindfulness, stress reduction, and physical activity with guided exercises.'
    },
    {
      id: 'custom',
      title: 'Custom Experience',
      description: 'Tailor the walk to your specific needs and goals with our customizable options.'
    }
  ];

  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Select Walk Type</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {walkTypes.map(type => (
          <div 
            key={type.id}
            className={`border rounded-lg p-4 cursor-pointer hover:border-primary transition ${selectedType === type.id ? 'border-primary bg-green-50' : 'border-gray-200'}`}
            onClick={() => onSelect(type.id)}
          >
            <div className="font-semibold mb-2">{type.title}</div>
            <p className="text-sm text-gray-600">{type.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WalkTypeSelector;
