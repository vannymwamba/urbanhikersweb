import React from 'react';
import CorporateBookingForm from './CorporateBookingForm';

const CorporateBooking = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-display font-bold mb-6">Corporate Urban Hiking Events</h1>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Team Building Through Urban Exploration</h2>
          <p className="text-gray-700 mb-4">
            Discover a unique way to strengthen team bonds, boost morale, and promote wellness with our customized corporate urban hiking experiences. Our guided walks combine team-building activities with the exploration of fascinating urban landscapes, creating memorable shared experiences for your team.
          </p>
          <p className="text-gray-700 mb-4">
            Whether you're looking for a creative off-site meeting alternative, a team-building activity, or a wellness initiative, our corporate urban hikes can be tailored to meet your specific goals and company culture.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-primary mb-2">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <h3 className="font-semibold text-lg mb-2">Team Building</h3>
            <p className="text-gray-600">
              Interactive challenges and shared experiences that foster collaboration, communication, and team spirit.
            </p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-primary mb-2">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="font-semibold text-lg mb-2">Flexible Scheduling</h3>
            <p className="text-gray-600">
              Morning, afternoon, or evening walks available on weekdays and weekends to accommodate your team's schedule.
            </p>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-primary mb-2">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 3l-6 6m0 0V4m0 5h5M5 3a2 2 0 00-2 2v1c0 8.284 6.716 15 15 15h1a2 2 0 002-2v-3.28a1 1 0 00-.684-.948l-4.493-1.498a1 1 0 00-1.21.502l-1.13 2.257a11.042 11.042 0 01-5.516-5.517l2.257-1.128a1 1 0 00.502-1.21L9.228 3.683A1 1 0 008.279 3H5z" />
              </svg>
            </div>
            <h3 className="font-semibold text-lg mb-2">Customized Experience</h3>
            <p className="text-gray-600">
              Tailor the route, activities, and themes to align with your company values, goals, or current initiatives.
            </p>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Popular Corporate Walk Themes</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border-l-4 border-primary pl-4">
              <h3 className="font-semibold mb-1">Historical Discovery</h3>
              <p className="text-gray-600 text-sm">
                Explore the city's rich history while engaging in team challenges that connect past innovations to present-day problem-solving.
              </p>
            </div>
            <div className="border-l-4 border-primary pl-4">
              <h3 className="font-semibold mb-1">Urban Innovation</h3>
              <p className="text-gray-600 text-sm">
                Visit cutting-edge urban developments and discuss how creative solutions shape our cities and businesses.
              </p>
            </div>
            <div className="border-l-4 border-primary pl-4">
              <h3 className="font-semibold mb-1">Wellness Walk</h3>
              <p className="text-gray-600 text-sm">
                Focus on physical and mental well-being with mindfulness exercises, stretching breaks, and discussions on work-life balance.
              </p>
            </div>
            <div className="border-l-4 border-primary pl-4">
              <h3 className="font-semibold mb-1">Creative Inspiration</h3>
              <p className="text-gray-600 text-sm">
                Discover street art, architecture, and design elements that spark creativity and innovative thinking.
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">What's Included</h2>
          <ul className="space-y-2">
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Professional guide with expertise in team facilitation</span>
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Customized route planning based on your objectives</span>
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Team-building activities and challenges</span>
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Bottled water and light refreshments</span>
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Digital photos of your team during the experience</span>
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Optional post-walk debrief session</span>
            </li>
          </ul>
        </div>
        
        <div className="bg-gray-50 rounded-lg p-6 mb-8">
          <div className="flex items-start">
            <div className="mr-4 text-primary">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Pricing Information</h3>
              <p className="text-gray-600 mb-2">
                Corporate urban hikes are priced based on group size, duration, and specific requirements. Our packages start at $300 for groups up to 10 people.
              </p>
              <p className="text-gray-600">
                Submit your request below, and our corporate events team will contact you with a customized quote within 24 hours.
              </p>
            </div>
          </div>
        </div>
        
        <h2 className="text-2xl font-bold mb-6">Request a Corporate Booking</h2>
        <CorporateBookingForm />
      </div>
    </div>
  );
};

export default CorporateBooking;
