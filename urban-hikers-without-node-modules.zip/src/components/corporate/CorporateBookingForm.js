import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { corporateService } from '../services/corporate';

const CorporateBookingForm = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    companyName: '',
    contactName: '',
    email: '',
    phone: '',
    participants: '',
    walkType: '',
    preferredDate: '',
    alternateDate: '',
    specialRequirements: ''
  });
  
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
  };
  
  const validateStep1 = () => {
    const newErrors = {};
    
    if (!formData.companyName.trim()) {
      newErrors.companyName = 'Company name is required';
    }
    
    if (!formData.contactName.trim()) {
      newErrors.contactName = 'Contact name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const validateStep2 = () => {
    const newErrors = {};
    
    if (!formData.participants) {
      newErrors.participants = 'Number of participants is required';
    }
    
    if (!formData.walkType) {
      newErrors.walkType = 'Walk type is required';
    }
    
    if (!formData.preferredDate) {
      newErrors.preferredDate = 'Preferred date is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const nextStep = () => {
    if (currentStep === 1 && validateStep1()) {
      setCurrentStep(2);
    } else if (currentStep === 2 && validateStep2()) {
      setCurrentStep(3);
    }
  };
  
  const prevStep = () => {
    setCurrentStep(currentStep - 1);
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    setIsSubmitting(true);
    
    try {
      const response = await corporateService.submitCorporateBooking(formData);
      
      setBookingSuccess(true);
      setIsSubmitting(false);
      
      // Scroll to top
      window.scrollTo(0, 0);
    } catch (error) {
      setErrors({
        submit: error.message || 'Failed to submit booking request. Please try again.'
      });
      setIsSubmitting(false);
    }
  };
  
  if (bookingSuccess) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
          <svg className="w-16 h-16 text-green-500 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
          <h2 className="text-2xl font-bold text-green-800 mb-2">Booking Request Submitted!</h2>
          <p className="text-green-700 mb-4">
            Thank you for your corporate booking request. Our team will review your request and contact you within 24 hours to confirm details and pricing.
          </p>
          <p className="text-green-700 mb-6">
            A confirmation email has been sent to {formData.email}.
          </p>
          <button
            onClick={() => navigate('/')}
            className="bg-primary hover:bg-primary-dark text-white px-6 py-2 rounded-md transition"
          >
            Return to Home
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-gray-50 p-4 border-b">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold">Corporate Booking Request</h2>
          <div className="text-sm text-gray-500">Step {currentStep} of 3</div>
        </div>
        <div className="mt-4 flex">
          <div className={`flex-1 border-t-4 ${currentStep >= 1 ? 'border-primary' : 'border-gray-200'}`}></div>
          <div className={`flex-1 border-t-4 ${currentStep >= 2 ? 'border-primary' : 'border-gray-200'}`}></div>
          <div className={`flex-1 border-t-4 ${currentStep >= 3 ? 'border-primary' : 'border-gray-200'}`}></div>
        </div>
      </div>
      
      <div className="p-6">
        {errors.submit && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-md">
            {errors.submit}
          </div>
        )}
        
        <form onSubmit={handleSubmit}>
          {currentStep === 1 && (
            <div>
              <h3 className="text-lg font-semibold mb-4">Company Information</h3>
              
              <div className="mb-4">
                <label htmlFor="companyName" className="block text-gray-700 mb-1">Company Name *</label>
                <input
                  type="text"
                  id="companyName"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary ${errors.companyName ? 'border-red-500' : 'border-gray-300'}`}
                />
                {errors.companyName && <p className="text-red-500 text-sm mt-1">{errors.companyName}</p>}
              </div>
              
              <div className="mb-4">
                <label htmlFor="contactName" className="block text-gray-700 mb-1">Contact Person Name *</label>
                <input
                  type="text"
                  id="contactName"
                  name="contactName"
                  value={formData.contactName}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary ${errors.contactName ? 'border-red-500' : 'border-gray-300'}`}
                />
                {errors.contactName && <p className="text-red-500 text-sm mt-1">{errors.contactName}</p>}
              </div>
              
              <div className="mb-4">
                <label htmlFor="email" className="block text-gray-700 mb-1">Email *</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary ${errors.email ? 'border-red-500' : 'border-gray-300'}`}
                />
                {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
              </div>
              
              <div className="mb-6">
                <label htmlFor="phone" className="block text-gray-700 mb-1">Phone Number *</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary ${errors.phone ? 'border-red-500' : 'border-gray-300'}`}
                />
                {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
              </div>
              
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={nextStep}
                  className="bg-primary hover:bg-primary-dark text-white px-6 py-2 rounded-md transition"
                >
                  Next Step
                </button>
              </div>
            </div>
          )}
          
          {currentStep === 2 && (
            <div>
              <h3 className="text-lg font-semibold mb-4">Event Details</h3>
              
              <div className="mb-4">
                <label htmlFor="participants" className="block text-gray-700 mb-1">Number of Participants *</label>
                <select
                  id="participants"
                  name="participants"
                  value={formData.participants}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary ${errors.participants ? 'border-red-500' : 'border-gray-300'}`}
                >
                  <option value="">Select number of participants</option>
                  <option value="1-10">1-10 people</option>
                  <option value="11-20">11-20 people</option>
                  <option value="21-30">21-30 people</option>
                  <option value="31-50">31-50 people</option>
                  <option value="50+">More than 50 people</option>
                </select>
                {errors.participants && <p className="text-red-500 text-sm mt-1">{errors.participants}</p>}
              </div>
              
              <div className="mb-4">
                <label htmlFor="walkType" className="block text-gray-700 mb-1">Type of Walk *</label>
                <select
                  id="walkType"
                  name="walkType"
                  value={formData.walkType}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary ${errors.walkType ? 'border-red-500' : 'border-gray-300'}`}
                >
                  <option value="">Select walk type</option>
                  <option value="teambuilding">Team Building</option>
                  <option value="historical">Historical Tour</option>
                  <option value="cultural">Cultural Experience</option>
                  <option value="architectural">Architectural Tour</option>
                  <option value="custom">Custom Experience</option>
                </select>
                {errors.walkType && <p className="text-red-500 text-sm mt-1">{errors.walkType}</p>}
              </div>
              
              <div className="mb-4">
                <label htmlFor="preferredDate" className="block text-gray-700 mb-1">Preferred Date *</label>
                <input
                  type="date"
                  id="preferredDate"
                  name="preferredDate"
                  value={formData.preferredDate}
                  onChange={handleChange}
                  min={new Date().toISOString().split('T')[0]}
                  className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary ${errors.preferredDate ? 'border-red-500' : 'border-gray-300'}`}
                />
                {errors.preferredDate && <p className="text-red-500 text-sm mt-1">{errors.preferredDate}</p>}
              </div>
              
              <div className="mb-6">
                <label htmlFor="alternateDate" className="block text-gray-700 mb-1">Alternate Date (Optional)</label>
                <input
                  type="date"
                  id="alternateDate"
                  name="alternateDate"
                  value={formData.alternateDate}
                  onChange={handleChange}
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={prevStep}
                  className="border border-gray-300 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-50 transition"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={nextStep}
                  className="bg-primary hover:bg-primary-dark text-white px-6 py-2 rounded-md transition"
                >
                  Next Step
                </button>
              </div>
            </div>
          )}
          
          {currentStep === 3 && (
            <div>
              <h3 className="text-lg font-semibold mb-4">Additional Information</h3>
              
              <div className="mb-6">
                <label htmlFor="specialRequirements" className="block text-gray-700 mb-1">Special Requirements or Requests</label>
                <textarea
                  id="specialRequirements"
                  name="specialRequirements"
                  value={formData.specialRequirements}
                  onChange={handleChange}
                  rows="4"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Please let us know about any special requirements, accessibility needs, or specific themes you'd like for your corporate event."
                ></textarea>
              </div>
              
              <div className="mb-6 p-4 bg-gray-50 rounded-md">
                <h4 className="font-semibold mb-2">What Happens Next?</h4>
                <p className="text-sm text-gray-600 mb-2">
                  After submitting your request:
                </p>
                <ol className="text-sm text-gray-600 list-decimal pl-5 space-y-1">
                  <li>Our corporate events team will review your request</li>
                  <li>We'll contact you within 24 hours to discuss details and pricing</li>
                  <li>Once confirmed, you'll receive a formal proposal and invoice</li>
                  <li>Your booking is secured upon payment of the deposit</li>
                </ol>
              </div>
              
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={prevStep}
                  className="border border-gray-300 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-50 transition"
                >
                  Previous
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`bg-primary hover:bg-primary-dark text-white px-6 py-2 rounded-md transition ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Booking Request'}
                </button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default CorporateBookingForm;
