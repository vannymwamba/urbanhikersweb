import React from 'react';

const CompanyInfoForm = ({ formData, onChange }) => {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Company Information</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label htmlFor="companyName" className="block text-gray-700 mb-1">Company Name *</label>
          <input
            type="text"
            id="companyName"
            name="companyName"
            value={formData.companyName}
            onChange={onChange}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <div>
          <label htmlFor="contactName" className="block text-gray-700 mb-1">Contact Person *</label>
          <input
            type="text"
            id="contactName"
            name="contactName"
            value={formData.contactName}
            onChange={onChange}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label htmlFor="email" className="block text-gray-700 mb-1">Email *</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={onChange}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <div>
          <label htmlFor="phone" className="block text-gray-700 mb-1">Phone Number *</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={onChange}
            required
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
      </div>
      
      <div className="mb-6">
        <label htmlFor="participants" className="block text-gray-700 mb-1">Estimated Number of Participants *</label>
        <select
          id="participants"
          name="participants"
          value={formData.participants}
          onChange={onChange}
          required
          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
        >
          <option value="">Select group size</option>
          <option value="5-10">5-10 people</option>
          <option value="11-20">11-20 people</option>
          <option value="21-30">21-30 people</option>
          <option value="31-50">31-50 people</option>
          <option value="50+">More than 50 people</option>
        </select>
      </div>
    </div>
  );
};

export default CompanyInfoForm;
