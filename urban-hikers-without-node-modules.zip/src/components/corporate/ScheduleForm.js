import React from 'react';

const ScheduleForm = ({ formData, onChange }) => {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Schedule & Requirements</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label htmlFor="preferredDate" className="block text-gray-700 mb-1">Preferred Date *</label>
          <input
            type="date"
            id="preferredDate"
            name="preferredDate"
            value={formData.preferredDate}
            onChange={onChange}
            required
            min={new Date().toISOString().split('T')[0]}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        <div>
          <label htmlFor="alternateDate" className="block text-gray-700 mb-1">Alternate Date</label>
          <input
            type="date"
            id="alternateDate"
            name="alternateDate"
            value={formData.alternateDate}
            onChange={onChange}
            min={new Date().toISOString().split('T')[0]}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
      </div>
      
      <div className="mb-6">
        <label htmlFor="specialRequirements" className="block text-gray-700 mb-1">Special Requirements or Requests</label>
        <textarea
          id="specialRequirements"
          name="specialRequirements"
          value={formData.specialRequirements}
          onChange={onChange}
          rows="4"
          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          placeholder="Any accessibility needs, dietary restrictions, or specific requests for your event?"
        ></textarea>
      </div>
      
      <div className="bg-gray-50 p-4 rounded-md mb-6">
        <h4 className="font-semibold mb-2">What happens next?</h4>
        <p className="text-sm text-gray-600">
          After submitting your request, our corporate events team will contact you within 1-2 business days to discuss details, pricing, and customize your urban hiking experience.
        </p>
      </div>
    </div>
  );
};

export default ScheduleForm;
