import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';

const EventDetail = () => {
  const { id } = useParams();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);

  // Mock data for a single event
  const mockEvent = {
    id: parseInt(id),
    title: 'Historical Downtown Tour',
    date: 'April 15, 2025',
    time: '10:00 AM - 12:30 PM',
    location: 'City Center',
    meetingPoint: 'Central Square Fountain',
    image: '/images/placeholder/downtown.jpg',
    price: '$25',
    spotsLeft: 8,
    category: 'historical',
    description: 'Join us for a fascinating journey through the historical heart of downtown. This guided walk will take you through centuries of urban development, architectural marvels, and the stories behind the city's most iconic landmarks. Our expert guide will share insights about the cultural and historical significance of each location.',
    highlights: [
      'Visit 5 historical landmarks',
      'Learn about architectural styles spanning 3 centuries',
      'Discover hidden courtyards and secret passages',
      'Hear fascinating stories about the city's founders',
      'Small group size for a personalized experience'
    ],
    includes: [
      'Professional guide',
      'Bottled water',
      'Historical map souvenir',
      'Access to exclusive locations'
    ],
    guide: {
      name: 'Professor Alex Thompson',
      bio: 'Alex is a history professor with over 15 years of experience leading urban tours. His passion for local history and engaging storytelling style make each tour educational and entertaining.',
      image: '/images/placeholder/guide.jpg'
    },
    duration: '2.5 hours',
    distance: '2.5 miles',
    difficulty: 'Easy',
    maxParticipants: 12
  };

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setEvent(mockEvent);
      setLoading(false);
    }, 500);
  }, [id]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Event Not Found</h2>
          <p className="mb-6">The event you're looking for doesn't exist or has been removed.</p>
          <Link to="/events" className="bg-primary hover:bg-primary-dark text-white px-6 py-2 rounded-md transition duration-300">
            Back to Events
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-6">
        <Link to="/events" className="text-primary hover:text-primary-dark flex items-center">
          <svg className="w-5 h-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Back to Events
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-gray-300 h-80 rounded-lg mb-6 flex items-center justify-center text-gray-500">
            <span>Event Image</span>
          </div>
          
          <h1 className="text-3xl font-display font-bold mb-4">{event.title}</h1>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="text-primary mb-1">
                <svg className="w-5 h-5 inline-block" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <div className="text-sm text-gray-500">Date</div>
              <div className="font-semibold">{event.date}</div>
            </div>
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="text-primary mb-1">
                <svg className="w-5 h-5 inline-block" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div className="text-sm text-gray-500">Time</div>
              <div className="font-semibold">{event.time}</div>
            </div>
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="text-primary mb-1">
                <svg className="w-5 h-5 inline-block" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div className="text-sm text-gray-500">Duration</div>
              <div className="font-semibold">{event.duration}</div>
            </div>
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="text-primary mb-1">
                <svg className="w-5 h-5 inline-block" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <div className="text-sm text-gray-500">Distance</div>
              <div className="font-semibold">{event.distance}</div>
            </div>
          </div>
          
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">About This Event</h2>
            <p className="text-gray-700 mb-4">{event.description}</p>
            
            <h3 className="font-bold mt-6 mb-2">Highlights:</h3>
            <ul className="list-disc pl-5 mb-4">
              {event.highlights.map((highlight, index) => (
                <li key={index} className="text-gray-700 mb-1">{highlight}</li>
              ))}
            </ul>
            
            <h3 className="font-bold mt-6 mb-2">What's Included:</h3>
            <ul className="list-disc pl-5">
              {event.includes.map((item, index) => (
                <li key={index} className="text-gray-700 mb-1">{item}</li>
              ))}
            </ul>
          </div>
          
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">Meeting Point</h2>
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="flex items-start">
                <svg className="w-5 h-5 mr-2 text-primary mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <div>
                  <div className="font-semibold">{event.meetingPoint}</div>
                  <div className="text-gray-600">{event.location}</div>
                  <div className="text-sm text-primary mt-2">View on map</div>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h2 className="text-xl font-bold mb-4">Your Guide</h2>
            <div className="flex items-start bg-gray-100 p-4 rounded-lg">
              <div className="w-16 h-16 bg-gray-300 rounded-full mr-4 flex items-center justify-center text-gray-500 text-xs">
                Photo
              </div>
              <div>
                <div className="font-semibold">{event.guide.name}</div>
                <p className="text-gray-700 mt-1">{event.guide.bio}</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6 sticky top-6">
            <div className="text-2xl font-bold mb-2">{event.price}</div>
            <div className="text-gray-600 mb-6">per person</div>
            
            <div className="mb-6">
              <div className="flex justify-between mb-2">
                <span>Difficulty:</span>
                <span className="font-semibold">{event.difficulty}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span>Group Size:</span>
                <span className="font-semibold">Max {event.maxParticipants} people</span>
              </div>
              <div className="flex justify-between mb-2">
                <span>Availability:</span>
                <span className="font-semibold">{event.spotsLeft} spots left</span>
              </div>
            </div>
            
            <Link 
              to={`/events/${event.id}/register`} 
              className="block w-full bg-primary hover:bg-primary-dark text-white text-center px-4 py-3 rounded-md transition duration-300 mb-4"
            >
              Book Now
            </Link>
            
            <button className="block w-full border border-gray-300 text-gray-700 hover:bg-gray-50 text-center px-4 py-3 rounded-md transition duration-300">
              Add to Calendar
            </button>
            
            <div className="mt-6 text-sm text-gray-600">
              <p className="mb-2">
                <svg className="w-5 h-5 inline-block mr-1 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Free cancellation up to 24 hours before the event
              </p>
              <p>
                <svg className="w-5 h-5 inline-block mr-1 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Weather guarantee - reschedule if needed
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventDetail;
