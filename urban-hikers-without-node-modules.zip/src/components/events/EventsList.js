import React, { useState, useEffect } from 'react';
import EventCard from './EventCard';

const EventsList = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  // Mock data for events
  const mockEvents = [
    {
      id: 1,
      title: 'Historical Downtown Tour',
      date: 'April 15, 2025',
      time: '10:00 AM - 12:30 PM',
      location: 'City Center',
      image: '/images/placeholder/downtown.jpg',
      price: '$25',
      spotsLeft: 8,
      category: 'historical'
    },
    {
      id: 2,
      title: 'Street Art Discovery Walk',
      date: 'April 18, 2025',
      time: '2:00 PM - 4:00 PM',
      location: 'Arts District',
      image: '/images/placeholder/street-art.jpg',
      price: '$20',
      spotsLeft: 12,
      category: 'cultural'
    },
    {
      id: 3,
      title: 'Urban Nature Hike',
      date: 'April 22, 2025',
      time: '9:00 AM - 11:30 AM',
      location: 'Riverside Park',
      image: '/images/placeholder/urban-nature.jpg',
      price: '$22',
      spotsLeft: 5,
      category: 'nature'
    },
    {
      id: 4,
      title: 'Architectural Wonders Walk',
      date: 'April 25, 2025',
      time: '1:00 PM - 3:30 PM',
      location: 'Downtown',
      image: '/images/placeholder/architecture.jpg',
      price: '$28',
      spotsLeft: 15,
      category: 'architectural'
    },
    {
      id: 5,
      title: 'Culinary Tour & Tastings',
      date: 'April 29, 2025',
      time: '11:00 AM - 2:00 PM',
      location: 'Food District',
      image: '/images/placeholder/culinary.jpg',
      price: '$35',
      spotsLeft: 6,
      category: 'culinary'
    },
    {
      id: 6,
      title: 'Night Photography Walk',
      date: 'May 2, 2025',
      time: '7:30 PM - 10:00 PM',
      location: 'City Lights Area',
      image: '/images/placeholder/night.jpg',
      price: '$30',
      spotsLeft: 10,
      category: 'photography'
    }
  ];

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setEvents(mockEvents);
      setLoading(false);
    }, 500);
  }, []);

  const filteredEvents = filter === 'all' 
    ? events 
    : events.filter(event => event.category === filter);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-display font-bold mb-6">Upcoming Urban Hikes</h2>
        
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={() => setFilter('all')} 
            className={`px-4 py-2 rounded-md ${filter === 'all' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            All Events
          </button>
          <button 
            onClick={() => setFilter('historical')} 
            className={`px-4 py-2 rounded-md ${filter === 'historical' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            Historical
          </button>
          <button 
            onClick={() => setFilter('cultural')} 
            className={`px-4 py-2 rounded-md ${filter === 'cultural' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            Cultural
          </button>
          <button 
            onClick={() => setFilter('nature')} 
            className={`px-4 py-2 rounded-md ${filter === 'nature' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            Nature
          </button>
          <button 
            onClick={() => setFilter('architectural')} 
            className={`px-4 py-2 rounded-md ${filter === 'architectural' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            Architectural
          </button>
          <button 
            onClick={() => setFilter('culinary')} 
            className={`px-4 py-2 rounded-md ${filter === 'culinary' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            Culinary
          </button>
          <button 
            onClick={() => setFilter('photography')} 
            className={`px-4 py-2 rounded-md ${filter === 'photography' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            Photography
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredEvents.length > 0 ? (
            filteredEvents.map(event => (
              <EventCard key={event.id} event={event} />
            ))
          ) : (
            <div className="col-span-3 text-center py-12">
              <p className="text-xl text-gray-600">No events found matching your criteria.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default EventsList;
