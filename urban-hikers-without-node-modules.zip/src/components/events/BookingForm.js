import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { eventsService } from '../services/events';

const BookingForm = ({ event, userId = 1 }) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    participants: 1,
    name: '',
    email: '',
    phone: '',
    specialRequests: ''
  });
  
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  
  const totalPrice = event ? event.price * formData.participants : 0;
  
  const handleChange = (e) => {
    const { name, value, type } = e.target;
    
    if (type === 'number') {
      // Ensure participants is between 1 and available spots
      const numValue = parseInt(value);
      const maxParticipants = event ? event.spotsLeft : 1;
      
      if (numValue < 1) {
        setFormData({ ...formData, [name]: 1 });
      } else if (numValue > maxParticipants) {
        setFormData({ ...formData, [name]: maxParticipants });
      } else {
        setFormData({ ...formData, [name]: numValue });
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
  };
  
  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      setIsSubmitting(true);
      
      try {
        const bookingData = {
          userId: userId,
          eventId: event.id,
          date: event.date,
          time: event.time,
          participants: formData.participants,
          totalPrice: totalPrice,
          customerName: formData.name,
          customerEmail: formData.email,
          customerPhone: formData.phone,
          specialRequests: formData.specialRequests
        };
        
        const response = await eventsService.bookEvent(bookingData);
        
        setBookingSuccess(true);
        setIsSubmitting(false);
        
        // Redirect to confirmation page after 2 seconds
        setTimeout(() => {
          navigate('/profile');
        }, 2000);
      } catch (error) {
        setErrors({
          submit: error.message || 'Failed to book event. Please try again.'
        });
        setIsSubmitting(false);
      }
    }
  };
  
  if (!event) {
    return <div>Loading event details...</div>;
  }
  
  if (bookingSuccess) {
    return (
      <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
        <svg className="w-16 h-16 text-green-500 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
        </svg>
        <h2 className="text-2xl font-bold text-green-800 mb-2">Booking Confirmed!</h2>
        <p className="text-green-700 mb-4">
          Thank you for booking {event.title}. We've sent a confirmation email to {formData.email}.
        </p>
        <p className="text-sm text-green-600">
          Redirecting to your profile page...
        </p>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Book Your Spot</h2>
      
      <div className="mb-6 p-4 bg-gray-50 rounded-md">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="font-semibold text-lg">{event.title}</h3>
            <div className="text-gray-600">{event.date} • {event.time}</div>
            <div className="text-gray-600">{event.location}</div>
          </div>
          <div className="text-right">
            <div className="text-primary font-bold text-xl">${event.price} / person</div>
            <div className="text-gray-500 text-sm">{event.spotsLeft} spots left</div>
          </div>
        </div>
      </div>
      
      {errors.submit && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 text-red-700 rounded-md">
          {errors.submit}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="mb-6">
          <label htmlFor="participants" className="block text-gray-700 mb-1">Number of Participants</label>
          <div className="flex items-center">
            <button
              type="button"
              onClick={() => handleChange({ target: { name: 'participants', value: formData.participants - 1, type: 'number' } })}
              disabled={formData.participants <= 1}
              className="px-3 py-2 border border-gray-300 rounded-l-md bg-gray-50 hover:bg-gray-100 disabled:opacity-50"
            >
              -
            </button>
            <input
              type="number"
              id="participants"
              name="participants"
              min="1"
              max={event.spotsLeft}
              value={formData.participants}
              onChange={handleChange}
              className="w-16 text-center py-2 border-t border-b border-gray-300 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => handleChange({ target: { name: 'participants', value: formData.participants + 1, type: 'number' } })}
              disabled={formData.participants >= event.spotsLeft}
              className="px-3 py-2 border border-gray-300 rounded-r-md bg-gray-50 hover:bg-gray-100 disabled:opacity-50"
            >
              +
            </button>
          </div>
        </div>
        
        <div className="mb-4">
          <label htmlFor="name" className="block text-gray-700 mb-1">Full Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary ${errors.name ? 'border-red-500' : 'border-gray-300'}`}
          />
          {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
        </div>
        
        <div className="mb-4">
          <label htmlFor="email" className="block text-gray-700 mb-1">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary ${errors.email ? 'border-red-500' : 'border-gray-300'}`}
          />
          {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
        </div>
        
        <div className="mb-4">
          <label htmlFor="phone" className="block text-gray-700 mb-1">Phone Number</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary ${errors.phone ? 'border-red-500' : 'border-gray-300'}`}
          />
          {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
        </div>
        
        <div className="mb-6">
          <label htmlFor="specialRequests" className="block text-gray-700 mb-1">Special Requests (Optional)</label>
          <textarea
            id="specialRequests"
            name="specialRequests"
            value={formData.specialRequests}
            onChange={handleChange}
            rows="3"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
          ></textarea>
        </div>
        
        <div className="mb-6 p-4 bg-gray-50 rounded-md">
          <h3 className="font-semibold mb-2">Order Summary</h3>
          <div className="flex justify-between mb-2">
            <div>{event.title} x {formData.participants}</div>
            <div>${event.price} x {formData.participants}</div>
          </div>
          <div className="border-t border-gray-200 pt-2 mt-2 flex justify-between font-bold">
            <div>Total</div>
            <div>${totalPrice.toFixed(2)}</div>
          </div>
        </div>
        
        <button
          type="submit"
          disabled={isSubmitting}
          className={`w-full bg-primary hover:bg-primary-dark text-white py-3 rounded-md transition ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
        >
          {isSubmitting ? 'Processing...' : `Complete Booking - $${totalPrice.toFixed(2)}`}
        </button>
      </form>
    </div>
  );
};

export default BookingForm;
