import React, { useState, useEffect } from 'react';

const BiometricAnalyzer = ({ biometricData, userPreferences }) => {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // This would normally be a complex algorithm that analyzes the biometric data
  // For demonstration purposes, we're using a simplified version
  useEffect(() => {
    // Simulate API call or complex calculation
    setLoading(true);
    
    try {
      setTimeout(() => {
        // Process the biometric data
        const processedData = analyzeBiometricData(biometricData, userPreferences);
        setAnalysis(processedData);
        setLoading(false);
      }, 1500);
    } catch (err) {
      setError('Error analyzing biometric data. Please try again.');
      setLoading(false);
    }
  }, [biometricData, userPreferences]);

  // Mock function to analyze biometric data
  const analyzeBiometricData = (data, preferences) => {
    // In a real application, this would be a complex algorithm
    // that analyzes the foot measurements and user preferences
    
    // Example analysis result
    return {
      footProfile: {
        archType: determineArchType(data),
        footWidth: determineFootWidth(data),
        pronation: determinePronation(data),
        gaitType: determineGaitType(data)
      },
      recommendedFeatures: {
        cushioning: determineCushioning(data, preferences),
        support: determineSupport(data, preferences),
        flexibility: determineFlexibility(data, preferences),
        durability: determineDurability(preferences)
      }
    };
  };

  // Helper functions for analysis
  const determineArchType = (data) => {
    // Using left_arch_height and right_arch_height from biometric data
    const leftArchHeight = data.measurements?.left_arch_height || 0;
    const rightArchHeight = data.measurements?.right_arch_height || 0;
    
    // Average arch height
    const avgArchHeight = (leftArchHeight + rightArchHeight) / 2;
    
    if (avgArchHeight < 0.01) return 'Low';
    if (avgArchHeight < 0.02) return 'Medium';
    return 'High';
  };

  const determineFootWidth = (data) => {
    // Using left_width and right_width from biometric data
    const leftWidth = data.measurements?.left_width || 0;
    const rightWidth = data.measurements?.right_width || 0;
    
    // Average foot width
    const avgWidth = (leftWidth + rightWidth) / 2;
    
    if (avgWidth < 0.09) return 'Narrow';
    if (avgWidth < 0.11) return 'Regular';
    return 'Wide';
  };

  const determinePronation = (data) => {
    // Using various measurements to determine pronation
    // This is a simplified version
    const leftHalluxAngle = data.measurements?.left_hallux_valgus_angle || 0;
    const rightHalluxAngle = data.measurements?.right_hallux_valgus_angle || 0;
    
    const avgAngle = (leftHalluxAngle + rightHalluxAngle) / 2;
    
    if (avgAngle < 4) return 'Supination';
    if (avgAngle < 6) return 'Neutral';
    return 'Overpronation';
  };

  const determineGaitType = (data) => {
    // Using various measurements to determine gait type
    // This is a simplified version
    return 'Balanced'; // Default for demo
  };

  const determineCushioning = (data, preferences) => {
    // Based on activity level and foot measurements
    if (preferences.activityLevel === 'athletic' || preferences.footPain.length > 0) {
      return 'High';
    }
    if (preferences.activityLevel === 'active') {
      return 'Medium-High';
    }
    return 'Medium';
  };

  const determineSupport = (data, preferences) => {
    // Based on arch type and pronation
    const archType = determineArchType(data);
    const pronation = determinePronation(data);
    
    if (archType === 'Low' || pronation === 'Overpronation') {
      return 'High';
    }
    if (archType === 'High' || pronation === 'Supination') {
      return 'Medium';
    }
    return 'Neutral';
  };

  const determineFlexibility = (data, preferences) => {
    // Based on activity and terrain
    if (preferences.terrainType === 'trail') {
      return 'Low';
    }
    if (preferences.activityLevel === 'athletic') {
      return 'High';
    }
    return 'Medium';
  };

  const determineDurability = (preferences) => {
    // Based on activity level and terrain
    if (preferences.activityLevel === 'athletic' || preferences.terrainType === 'trail') {
      return 'High';
    }
    return 'Medium';
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold mb-4">Analyzing Your Biometric Data</h3>
        <div className="flex flex-col items-center justify-center py-8">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mb-4"></div>
          <p className="text-gray-600">Processing your foot measurements...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold mb-4">Analysis Error</h3>
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-md">
          <p>{error}</p>
        </div>
        <button 
          className="mt-4 bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-md transition"
          onClick={() => window.location.reload()}
        >
          Try Again
        </button>
      </div>
    );
  }

  if (!analysis) {
    return null;
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-lg font-semibold mb-4">Your Foot Analysis Results</h3>
      
      <div className="mb-6">
        <h4 className="font-semibold mb-3">Foot Profile</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-gray-50 p-3 rounded-md">
            <div className="text-sm text-gray-500">Arch Type</div>
            <div className="font-semibold">{analysis.footProfile.archType}</div>
          </div>
          <div className="bg-gray-50 p-3 rounded-md">
            <div className="text-sm text-gray-500">Foot Width</div>
            <div className="font-semibold">{analysis.footProfile.footWidth}</div>
          </div>
          <div className="bg-gray-50 p-3 rounded-md">
            <div className="text-sm text-gray-500">Pronation</div>
            <div className="font-semibold">{analysis.footProfile.pronation}</div>
          </div>
          <div className="bg-gray-50 p-3 rounded-md">
            <div className="text-sm text-gray-500">Gait Type</div>
            <div className="font-semibold">{analysis.footProfile.gaitType}</div>
          </div>
        </div>
      </div>
      
      <div className="mb-6">
        <h4 className="font-semibold mb-3">Recommended Shoe Features</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-gray-50 p-3 rounded-md">
            <div className="text-sm text-gray-500">Cushioning</div>
            <div className="font-semibold">{analysis.recommendedFeatures.cushioning}</div>
          </div>
          <div className="bg-gray-50 p-3 rounded-md">
            <div className="text-sm text-gray-500">Support</div>
            <div className="font-semibold">{analysis.recommendedFeatures.support}</div>
          </div>
          <div className="bg-gray-50 p-3 rounded-md">
            <div className="text-sm text-gray-500">Flexibility</div>
            <div className="font-semibold">{analysis.recommendedFeatures.flexibility}</div>
          </div>
          <div className="bg-gray-50 p-3 rounded-md">
            <div className="text-sm text-gray-500">Durability</div>
            <div className="font-semibold">{analysis.recommendedFeatures.durability}</div>
          </div>
        </div>
      </div>
      
      <div className="bg-green-50 border border-green-200 p-4 rounded-md mb-6">
        <div className="flex items-start">
          <div className="mr-3 text-green-500">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <h4 className="font-semibold">Analysis Complete</h4>
            <p className="text-sm text-gray-600">
              Based on your biometric data, we've analyzed your foot profile and determined the ideal shoe characteristics for your needs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BiometricAnalyzer;
