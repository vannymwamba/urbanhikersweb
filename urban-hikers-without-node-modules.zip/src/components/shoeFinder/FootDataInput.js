import React, { useState } from 'react';

const FootDataInput = ({ onDataSubmit }) => {
  const [manualMeasurements, setManualMeasurements] = useState({
    footLength: '',
    footWidth: '',
    archHeight: '',
    heelWidth: '',
    instepHeight: ''
  });

  const [uploadedFile, setUploadedFile] = useState(null);
  const [inputMethod, setInputMethod] = useState('upload'); // 'upload' or 'manual'

  const handleManualInputChange = (e) => {
    const { name, value } = e.target;
    setManualMeasurements({
      ...manualMeasurements,
      [name]: value
    });
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setUploadedFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (inputMethod === 'upload' && uploadedFile) {
      // In a real app, we would process the file here
      onDataSubmit({ type: 'file', data: uploadedFile });
    } else if (inputMethod === 'manual') {
      onDataSubmit({ type: 'manual', data: manualMeasurements });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-lg font-semibold mb-4">Foot Measurement Data</h3>
      
      <div className="mb-6">
        <div className="flex border-b border-gray-200">
          <button
            className={`py-2 px-4 font-medium ${inputMethod === 'upload' ? 'text-primary border-b-2 border-primary' : 'text-gray-500'}`}
            onClick={() => setInputMethod('upload')}
          >
            Upload Data
          </button>
          <button
            className={`py-2 px-4 font-medium ${inputMethod === 'manual' ? 'text-primary border-b-2 border-primary' : 'text-gray-500'}`}
            onClick={() => setInputMethod('manual')}
          >
            Manual Input
          </button>
        </div>
      </div>
      
      <form onSubmit={handleSubmit}>
        {inputMethod === 'upload' ? (
          <div>
            <div className="mb-6">
              <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center">
                <div className="mb-4">
                  <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                  </svg>
                </div>
                <p className="text-sm text-gray-600 mb-2">
                  Upload your foot scan data file (.json format)
                </p>
                <div className="flex justify-center">
                  <label className="cursor-pointer bg-white border border-gray-300 rounded-md px-4 py-2 hover:bg-gray-50 transition">
                    <span>{uploadedFile ? uploadedFile.name : 'Choose File'}</span>
                    <input 
                      type="file" 
                      className="hidden" 
                      accept=".json"
                      onChange={handleFileChange}
                    />
                  </label>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <div className="bg-gray-50 p-4 rounded-md">
                <h4 className="font-semibold mb-2">Supported Scanning Apps</h4>
                <p className="text-sm text-gray-600">
                  Our system supports data from the following foot scanning apps:
                </p>
                <ul className="text-sm text-gray-600 list-disc pl-5 mt-2">
                  <li>FootScan Pro</li>
                  <li>3D Foot Analyzer</li>
                  <li>WalkRight Scanner</li>
                  <li>Urban Hikers Mobile App</li>
                </ul>
              </div>
            </div>
          </div>
        ) : (
          <div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label htmlFor="footLength" className="block text-gray-700 mb-1">Foot Length (cm) *</label>
                <input
                  type="number"
                  step="0.1"
                  id="footLength"
                  name="footLength"
                  value={manualMeasurements.footLength}
                  onChange={handleManualInputChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label htmlFor="footWidth" className="block text-gray-700 mb-1">Foot Width (cm) *</label>
                <input
                  type="number"
                  step="0.1"
                  id="footWidth"
                  name="footWidth"
                  value={manualMeasurements.footWidth}
                  onChange={handleManualInputChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <label htmlFor="archHeight" className="block text-gray-700 mb-1">Arch Height (cm)</label>
                <input
                  type="number"
                  step="0.1"
                  id="archHeight"
                  name="archHeight"
                  value={manualMeasurements.archHeight}
                  onChange={handleManualInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label htmlFor="heelWidth" className="block text-gray-700 mb-1">Heel Width (cm)</label>
                <input
                  type="number"
                  step="0.1"
                  id="heelWidth"
                  name="heelWidth"
                  value={manualMeasurements.heelWidth}
                  onChange={handleManualInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <div>
                <label htmlFor="instepHeight" className="block text-gray-700 mb-1">Instep Height (cm)</label>
                <input
                  type="number"
                  step="0.1"
                  id="instepHeight"
                  name="instepHeight"
                  value={manualMeasurements.instepHeight}
                  onChange={handleManualInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>
            
            <div className="mb-6">
              <div className="bg-gray-50 p-4 rounded-md">
                <h4 className="font-semibold mb-2">How to Measure</h4>
                <p className="text-sm text-gray-600">
                  For the most accurate results, follow our <a href="#" className="text-primary hover:underline">measurement guide</a> or use our mobile app for 3D scanning.
                </p>
              </div>
            </div>
          </div>
        )}
        
        <div className="flex justify-end">
          <button
            type="submit"
            className="bg-primary hover:bg-primary-dark text-white px-6 py-2 rounded-md transition"
            disabled={inputMethod === 'upload' && !uploadedFile}
          >
            Submit Data
          </button>
        </div>
      </form>
    </div>
  );
};

export default FootDataInput;
