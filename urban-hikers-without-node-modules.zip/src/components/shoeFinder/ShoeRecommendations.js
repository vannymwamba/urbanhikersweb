import React from 'react';

const ShoeRecommendations = ({ recommendations, footProfile }) => {
  if (!recommendations || recommendations.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold mb-4">Shoe Recommendations</h3>
        <div className="text-center py-8">
          <p className="text-gray-600">No recommendations available. Please complete the analysis first.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-lg font-semibold mb-4">Your Personalized Shoe Recommendations</h3>
      
      <div className="mb-6">
        <div className="bg-green-50 border border-green-200 p-4 rounded-md">
          <div className="flex items-start">
            <div className="mr-3 text-green-500">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h4 className="font-semibold">Perfect Match Found</h4>
              <p className="text-sm text-gray-600">
                Based on your {footProfile?.archType || 'unique'} arch, {footProfile?.footWidth || 'specific'} foot width, and {footProfile?.pronation || 'personal'} pronation pattern, we've found shoes that will provide optimal comfort and support.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {recommendations.map((shoe, index) => (
          <div key={index} className="border rounded-lg overflow-hidden">
            <div className="h-48 bg-gray-200 flex items-center justify-center text-gray-500">
              {shoe.image ? (
                <img src={shoe.image} alt={shoe.name} className="h-full w-full object-cover" />
              ) : (
                <span>Shoe Image</span>
              )}
            </div>
            <div className="p-4">
              <h5 className="font-bold mb-1">{shoe.name}</h5>
              <div className="text-sm text-gray-600 mb-2">{shoe.category}</div>
              <div className="flex items-center mb-3">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <svg 
                      key={i} 
                      className="w-4 h-4" 
                      fill={i < Math.floor(shoe.rating) ? "currentColor" : "none"} 
                      viewBox="0 0 20 20"
                      stroke="currentColor"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span className="text-sm ml-1">{shoe.rating} ({shoe.reviewCount} reviews)</span>
              </div>
              <div className="text-primary font-bold mb-3">${shoe.price}</div>
              <div className="text-sm mb-3">
                <span className="font-semibold">Match Score:</span> {shoe.matchScore}%
              </div>
              <button className="w-full bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-md transition">
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mb-8">
        <h4 className="font-semibold mb-4">Why These Shoes Match Your Feet</h4>
        <div className="bg-gray-50 p-4 rounded-md">
          <ul className="space-y-3">
            {recommendations[0]?.matchReasons?.map((reason, index) => (
              <li key={index} className="flex items-start">
                <svg className="w-5 h-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>{reason}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      
      <div>
        <h4 className="font-semibold mb-4">Care and Maintenance Tips</h4>
        <div className="bg-gray-50 p-4 rounded-md">
          <p className="text-sm text-gray-600 mb-3">
            To get the most out of your recommended shoes, follow these care tips:
          </p>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>Allow your shoes to dry naturally after each use, away from direct heat sources.</span>
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>Clean your shoes regularly with appropriate cleaning products for the material.</span>
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>Replace your shoes every 300-500 miles of walking to maintain proper support.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ShoeRecommendations;
