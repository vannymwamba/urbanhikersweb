import React, { useState, useEffect } from 'react';
import FootDataInput from './FootDataInput';
import BiometricAnalyzer from './BiometricAnalyzer';
import ShoeRecommendations from './ShoeRecommendations';
import { shoeFinderService } from '../../services/shoeFinder';

const ShoeRecommendationEngine = () => {
  const [step, setStep] = useState(1);
  const [biometricData, setBiometricData] = useState(null);
  const [footProfile, setFootProfile] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [userPreferences, setUserPreferences] = useState({
    activityLevel: 'moderate',
    terrainType: 'urban',
    footPain: []
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Handle biometric data submission
  const handleDataSubmit = async (data) => {
    setLoading(true);
    setError(null);
    setBiometricData(data);
    
    try {
      // Process the biometric data
      const profile = await shoeFinderService.analyzeBiometricData(data);
      setFootProfile(profile);
      setStep(2);
      setLoading(false);
    } catch (err) {
      setError('Error analyzing biometric data. Please try again.');
      setLoading(false);
    }
  };

  // Handle user preferences update
  const handlePreferencesUpdate = (preferences) => {
    setUserPreferences({
      ...userPreferences,
      ...preferences
    });
  };

  // Get shoe recommendations based on foot profile and preferences
  useEffect(() => {
    if (footProfile && step === 2) {
      const getRecommendations = async () => {
        setLoading(true);
        try {
          const shoeRecommendations = await shoeFinderService.getShoeRecommendations(
            footProfile,
            userPreferences
          );
          setRecommendations(shoeRecommendations);
          setStep(3);
          setLoading(false);
        } catch (err) {
          setError('Error getting shoe recommendations. Please try again.');
          setLoading(false);
        }
      };
      
      getRecommendations();
    }
  }, [footProfile, userPreferences, step]);

  // Process the biometric data from the metadata.txt file
  const processMetadataFile = (fileData) => {
    // Parse the biometric data from the file
    // This would normally be more complex, parsing JSON or other formats
    // For demonstration, we'll create a simple object
    
    const measurements = {
      left_length: 26.5,
      right_length: 26.7,
      left_width: 10.2,
      right_width: 10.3,
      left_arch_height: 2.3,
      right_arch_height: 2.2,
      left_hallux_valgus_angle: 5.2,
      right_hallux_valgus_angle: 5.4,
      pronation_value: 5.8
    };
    
    return {
      type: 'scan',
      measurements,
      scanDate: new Date().toISOString()
    };
  };

  // Load sample data for demonstration
  const loadSampleData = () => {
    const sampleData = processMetadataFile("Sample biometric data");
    handleDataSubmit(sampleData);
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-display font-bold mb-6">Biometric Shoe Finder</h1>
        
        {loading && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="flex flex-col items-center justify-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mb-4"></div>
              <p className="text-gray-600">
                {step === 1 ? 'Processing your foot measurements...' : 'Finding your perfect shoes...'}
              </p>
            </div>
          </div>
        )}
        
        {error && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-md">
              <p>{error}</p>
            </div>
            <button 
              className="mt-4 bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-md transition"
              onClick={() => setError(null)}
            >
              Try Again
            </button>
          </div>
        )}
        
        {!loading && !error && (
          <>
            {step === 1 && (
              <div className="mb-8">
                <FootDataInput onDataSubmit={handleDataSubmit} />
                
                <div className="mt-6 text-center">
                  <p className="text-gray-600 mb-4">Don't have a foot scan? Try our sample data for demonstration:</p>
                  <button
                    onClick={loadSampleData}
                    className="bg-gray-100 hover:bg-gray-200 text-gray-800 px-4 py-2 rounded-md transition"
                  >
                    Use Sample Data
                  </button>
                </div>
              </div>
            )}
            
            {step === 2 && footProfile && (
              <BiometricAnalyzer 
                biometricData={biometricData} 
                userPreferences={userPreferences} 
              />
            )}
            
            {step === 3 && recommendations.length > 0 && (
              <ShoeRecommendations 
                recommendations={recommendations} 
                footProfile={footProfile} 
              />
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default ShoeRecommendationEngine;
