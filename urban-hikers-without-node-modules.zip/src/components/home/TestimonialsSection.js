import React from 'react';

const TestimonialsSection = () => {
  // Mock data for testimonials
  const testimonials = [
    {
      id: 1,
      name: 'Sarah Johnson',
      role: 'Regular Participant',
      quote: 'Urban Hikers has completely changed how I see my city. The guides are knowledgeable and the routes are always fascinating. Plus, their shoe recommendation was perfect for my flat feet!',
      image: '/images/placeholder/testimonial1.jpg'
    },
    {
      id: 2,
      name: 'Michael Chen',
      role: 'Corporate Client',
      quote: 'We booked a team-building walk with Urban Hikers and it was the highlight of our quarter. Everyone is still talking about the hidden gems we discovered just blocks from our office.',
      image: '/images/placeholder/testimonial2.jpg'
    },
    {
      id: 3,
      name: 'Emma Rodriguez',
      role: 'Photography Enthusiast',
      quote: 'The Street Art tour was incredible! Our guide knew all the best spots and the history behind each piece. The walking shoes they recommended handled all the terrain perfectly.',
      image: '/images/placeholder/testimonial3.jpg'
    }
  ];

  return (
    <section className="py-16 bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-display font-bold mb-4">What Our Hikers Say</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Don't just take our word for it. Here's what participants have to say about their Urban Hikers experience.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map(testimonial => (
            <div key={testimonial.id} className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-gray-300 mr-4 overflow-hidden">
                  {/* This would be replaced with actual images in production */}
                  <div className="w-full h-full flex items-center justify-center text-gray-500 text-xs">
                    Photo
                  </div>
                </div>
                <div>
                  <h3 className="font-bold">{testimonial.name}</h3>
                  <p className="text-gray-600 text-sm">{testimonial.role}</p>
                </div>
              </div>
              <div>
                <svg className="h-8 w-8 text-primary opacity-50 mb-2" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                </svg>
                <p className="text-gray-700 italic">{testimonial.quote}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <a href="/about#testimonials" className="inline-flex items-center text-primary hover:text-primary-dark font-semibold">
            Read More Testimonials
            <svg className="w-5 h-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
