import React from 'react';

const HeroSection = () => {
  return (
    <section className="relative bg-gray-900 text-white">
      {/* Background image with overlay */}
      <div className="absolute inset-0 bg-black opacity-50"></div>
      
      {/* Hero content */}
      <div className="relative container mx-auto px-4 py-24 md:py-32">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-6">
            Discover Your City on Foot
          </h1>
          <p className="text-xl mb-8">
            Join Urban Hikers for guided walks through hidden gems, historical landmarks, and vibrant neighborhoods. Experience your city like never before.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <a href="/events" className="bg-primary hover:bg-primary-dark text-white font-bold py-3 px-6 rounded-md transition duration-300 text-center">
              Browse Events
            </a>
            <a href="/shoe-finder" className="bg-white hover:bg-gray-100 text-gray-900 font-bold py-3 px-6 rounded-md transition duration-300 text-center">
              Find Perfect Shoes
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
