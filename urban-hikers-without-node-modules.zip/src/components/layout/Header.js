import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="flex items-center">
          <img src="/images/logo.svg" alt="Urban Hikers Logo" className="h-10 w-auto" />
          <span className="ml-2 text-xl font-display font-bold text-primary">Urban Hikers</span>
        </Link>
        
        <nav className="hidden md:flex space-x-8">
          <Link to="/" className="text-gray-700 hover:text-primary transition">Home</Link>
          <Link to="/events" className="text-gray-700 hover:text-primary transition">Events</Link>
          <Link to="/corporate" className="text-gray-700 hover:text-primary transition">Corporate</Link>
          <Link to="/shoe-finder" className="text-gray-700 hover:text-primary transition">Shoe Finder</Link>
          <Link to="/about" className="text-gray-700 hover:text-primary transition">About</Link>
        </nav>
        
        <div className="flex items-center space-x-4">
          <Link to="/login" className="text-gray-700 hover:text-primary transition">Login</Link>
          <Link to="/register" className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary-dark transition">Sign Up</Link>
          
          {/* Mobile menu button */}
          <button className="md:hidden text-gray-700 focus:outline-none">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
