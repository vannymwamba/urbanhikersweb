import React from 'react';
import UserProfile from '../components/auth/UserProfile';

const ProfilePage = () => {
  return (
    <div>
      <UserProfile />
    </div>
  );
};

export default ProfilePage;
