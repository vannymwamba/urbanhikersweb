import React from 'react';
import CorporateBooking from '../components/corporate/CorporateBooking';

const CorporatePage = () => {
  return (
    <div>
      <CorporateBooking />
    </div>
  );
};

export default CorporatePage;
