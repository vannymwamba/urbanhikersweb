import React from 'react';

const AboutPage = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-display font-bold mb-6">About Urban Hikers</h1>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Our Story</h2>
          <p className="text-gray-700 mb-4">
            Urban Hikers was founded in 2020 by a group of passionate city explorers who believed that the urban landscape offers just as much adventure, beauty, and discovery as traditional hiking trails. What started as informal weekend walks with friends has grown into a community of thousands of urban hiking enthusiasts.
          </p>
          <p className="text-gray-700 mb-4">
            Our mission is to help people rediscover their cities on foot, promoting physical activity, environmental awareness, and appreciation for urban design, architecture, and history. We believe that walking is not just a mode of transportation but a way to truly experience and connect with our urban environments.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">What We Offer</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-lg mb-2">Guided Urban Walks</h3>
              <p className="text-gray-700">
                Our expert guides lead themed walks through fascinating urban landscapes, revealing hidden gems, historical landmarks, and cultural hotspots that even locals might miss.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Corporate Team Events</h3>
              <p className="text-gray-700">
                We design custom urban hiking experiences for organizations looking to boost team morale, improve communication, and provide a unique team-building activity.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Biometric Shoe Finder</h3>
              <p className="text-gray-700">
                Our advanced technology analyzes your unique foot measurements to recommend the perfect walking shoes for your urban adventures, ensuring comfort and support.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Community Events</h3>
              <p className="text-gray-700">
                We organize regular community walks, workshops, and social gatherings to connect urban explorers and foster a sense of community among like-minded individuals.
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-bold mb-4">Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gray-300 mx-auto mb-4"></div>
              <h3 className="font-semibold">Sarah Johnson</h3>
              <p className="text-gray-600">Founder & Lead Guide</p>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gray-300 mx-auto mb-4"></div>
              <h3 className="font-semibold">Michael Chen</h3>
              <p className="text-gray-600">Corporate Events Director</p>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 rounded-full bg-gray-300 mx-auto mb-4"></div>
              <h3 className="font-semibold">Emma Rodriguez</h3>
              <p className="text-gray-600">Footwear Specialist</p>
            </div>
          </div>
        </div>
        
        <div id="testimonials" className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold mb-4">Testimonials</h2>
          <div className="space-y-6">
            <div className="bg-gray-50 p-4 rounded-md">
              <p className="italic text-gray-700 mb-2">
                "Urban Hikers has completely changed how I see my city. The guides are knowledgeable and the routes are always fascinating. Plus, their shoe recommendation was perfect for my flat feet!"
              </p>
              <div className="font-semibold">Sarah Johnson, Regular Participant</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-md">
              <p className="italic text-gray-700 mb-2">
                "We booked a team-building walk with Urban Hikers and it was the highlight of our quarter. Everyone is still talking about the hidden gems we discovered just blocks from our office."
              </p>
              <div className="font-semibold">Michael Chen, Corporate Client</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-md">
              <p className="italic text-gray-700 mb-2">
                "The Street Art tour was incredible! Our guide knew all the best spots and the history behind each piece. The walking shoes they recommended handled all the terrain perfectly."
              </p>
              <div className="font-semibold">Emma Rodriguez, Photography Enthusiast</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
