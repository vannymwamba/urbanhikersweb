import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { eventsService } from '../services/events';
import BookingForm from '../components/events/BookingForm';

const BookingPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const eventData = await eventsService.getEventById(parseInt(id));
        setEvent(eventData);
        setLoading(false);
      } catch (err) {
        setError('Event not found or unavailable. Please try again later.');
        setLoading(false);
      }
    };

    fetchEvent();
  }, [id]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Loading event details...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-md mb-4">
            {error}
          </div>
          <button
            onClick={() => navigate('/events')}
            className="bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-md transition"
          >
            Back to Events
          </button>
        </div>
      </div>
    );
  }

  if (event && event.spotsLeft === 0) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 p-4 rounded-md mb-6">
            <h2 className="text-xl font-bold mb-2">Event Fully Booked</h2>
            <p>
              We're sorry, but this event is currently fully booked. Please check our other events or check back later as spots may become available due to cancellations.
            </p>
          </div>
          <div className="text-center">
            <button
              onClick={() => navigate('/events')}
              className="bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-md transition"
            >
              Browse Other Events
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-display font-bold mb-6">Book Your Urban Hike</h1>
        <BookingForm event={event} />
      </div>
    </div>
  );
};

export default BookingPage;
