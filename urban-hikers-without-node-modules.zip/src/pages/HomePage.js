import React from 'react';
import HeroSection from '../components/home/HeroSection';
import FeaturesSection from '../components/home/FeaturesSection';
import EventsPreview from '../components/home/EventsPreview';
import TestimonialsSection from '../components/home/TestimonialsSection';

const HomePage = () => {
  return (
    <div>
      <HeroSection />
      <FeaturesSection />
      <EventsPreview />
      <TestimonialsSection />
    </div>
  );
};

export default HomePage;
