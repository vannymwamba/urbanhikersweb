import React from 'react';
import EventsList from '../components/events/EventsList';

const EventsPage = () => {
  return (
    <div className="py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-display font-bold mb-8">Urban Hiking Events</h1>
        <EventsList />
      </div>
    </div>
  );
};

export default EventsPage;
