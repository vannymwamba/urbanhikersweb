import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import EventDetail from '../components/events/EventDetail';
import EventRegistration from '../components/events/EventRegistration';

const EventDetailPage = () => {
  const { id } = useParams();
  const [showRegistration, setShowRegistration] = useState(false);
  
  useEffect(() => {
    // Check if the URL contains "register" to show registration form
    const path = window.location.pathname;
    if (path.includes('/register')) {
      setShowRegistration(true);
    }
  }, []);

  return (
    <div>
      {showRegistration ? (
        <EventRegistration />
      ) : (
        <EventDetail />
      )}
    </div>
  );
};

export default EventDetailPage;
