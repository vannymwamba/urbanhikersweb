import React from 'react';
import ShoeRecommendationEngine from '../components/shoeFinder/ShoeRecommendationEngine';

const ShoeFinderPage = () => {
  return (
    <div>
      <ShoeRecommendationEngine />
    </div>
  );
};

export default ShoeFinderPage;
