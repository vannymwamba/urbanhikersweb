import React from 'react';
import RegistrationForm from '../components/auth/RegistrationForm';

const RegistrationPage = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-md mx-auto">
        <RegistrationForm />
      </div>
    </div>
  );
};

export default RegistrationPage;
