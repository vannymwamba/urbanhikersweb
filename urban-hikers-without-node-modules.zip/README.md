# Urban Hikers Website

A React-based website for Urban Hikers, featuring event booking, corporate walks, and biometric shoe recommendations.

## Features

- **Event Booking**: Browse and book urban hiking events
- **Corporate Booking**: Request custom corporate walking events
- **Shoe Finder**: Get personalized shoe recommendations based on biometric data
- **User Authentication**: Create an account, login, and manage your profile

## Tech Stack

- React
- Tailwind CSS
- Context API for state management
- React Router for navigation

## Project Structure

```
urban-hikers/
│
├── public/
│   ├── index.html
│   ├── favicon.ico
│   └── images/
│       ├── logo.svg
│       └── placeholder/
│           └── ...
│
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Header.js
│   │   │   ├── Footer.js
│   │   │   └── Navigation.js
│   │   ├── home/
│   │   │   ├── HeroSection.js
│   │   │   ├── FeaturesSection.js
│   │   │   ├── EventsPreview.js
│   │   │   └── TestimonialsSection.js
│   │   ├── events/
│   │   │   ├── EventCard.js
│   │   │   ├── EventsList.js
│   │   │   ├── EventDetail.js
│   │   │   └── EventRegistration.js
│   │   ├── corporate/
│   │   │   ├── CorporateBooking.js
│   │   │   ├── WalkTypeSelector.js
│   │   │   ├── CompanyInfoForm.js
│   │   │   └── ScheduleForm.js
│   │   ├── shoeFinder/
│   │   │   ├── ShoeFinder.js
│   │   │   ├── FootDataInput.js
│   │   │   ├── BiometricAnalyzer.js
│   │   │   └── ShoeRecommendations.js
│   │   └── auth/
│   │       ├── LoginForm.js
│   │       ├── RegistrationForm.js
│   │       ├── UserProfile.js
│   │       └── ProtectedRoute.js
│   │
│   ├── pages/
│   │   ├── HomePage.js
│   │   ├── EventsPage.js
│   │   ├── EventDetailPage.js
│   │   ├── BookingPage.js
│   │   ├── CorporatePage.js
│   │   ├── ShoeFinderPage.js
│   │   ├── AboutPage.js
│   │   ├── LoginPage.js
│   │   ├── RegistrationPage.js
│   │   └── ProfilePage.js
│   │
│   ├── services/
│   │   ├── auth.js
│   │   ├── events.js
│   │   ├── corporate.js
│   │   ├── shoeFinder.js
│   │   └── mockData.js
│   │
│   ├── utils/
│   │   ├── formatters.js
│   │   └── validators.js
│   │
│   ├── context/
│   │   ├── AuthContext.js
│   │   └── UserContext.js
│   │
│   ├── App.js
│   ├── index.js
│   └── index.css
│
├── package.json
└── tailwind.config.js
```

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository
   ```
   git clone https://github.com/yourusername/urban-hikers.git
   cd urban-hikers
   ```

2. Install dependencies
   ```
   npm install
   ```

3. Start the development server
   ```
   npm start
   ```

4. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Biometric Shoe Finder

The shoe recommendation feature uses biometric data to suggest the best hiking shoes for users. The system analyzes:

- Foot length and width
- Arch height
- Pronation patterns
- Walking gait

## Authentication

The website includes a complete authentication system with:

- User registration
- Login/logout functionality
- Protected routes for booking and profile pages
- User profile management

## Deployment

To build the app for production:

```
npm run build
```

This creates an optimized build in the `build` folder ready for deployment.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
